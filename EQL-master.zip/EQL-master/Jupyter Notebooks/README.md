# Details:
Jupyter notebook which explores and recreates results demonstrated
in the paper regarding learning ability of network on simple 
sine function. Demonstrates library usage syntax and 
network capabilities.

![Imgur](https://i.imgur.com/9ptgKNY.png)