Symbolic Regression
===================

.. mdinclude:: doc_getting_started_sr.md

.. mdinclude:: doc_sr_plus.md

