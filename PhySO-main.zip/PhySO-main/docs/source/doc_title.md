# $\Phi$-SO : Physical Symbolic Optimization
