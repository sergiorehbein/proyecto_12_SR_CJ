.. mdinclude:: doc_performances.md
