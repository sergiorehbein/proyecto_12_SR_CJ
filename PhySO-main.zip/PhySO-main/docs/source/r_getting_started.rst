.. mdinclude:: doc_getting_started_header.md

.. mdinclude:: doc_getting_started_sr.md