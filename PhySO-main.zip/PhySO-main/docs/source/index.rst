Welcome to PhySO's documentation!
===================================

.. mdinclude:: doc_logo.md

.. mdinclude:: doc_header.md

.. include:: doc_presentation_rtd.rst


Contents
--------

.. toctree::
   :maxdepth: 2

   r_installation
   r_getting_started
   r_sr
   r_performances
   r_reproducibility
   r_reference